
package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/balance/{id}")
    public String getBalance(@PathVariable Long id) {
        return "Balance: " + userRepository.findById(id).get().getBalance();
    }
}
